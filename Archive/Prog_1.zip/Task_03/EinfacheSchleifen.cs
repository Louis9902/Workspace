﻿using System;

namespace Ohm.Homework
{
    class EinfacheSchleifen
    {
        private const double CancelNumber = 1.0E-9;

        static void Main(string[] args)
        {
            int counter = 0;
            string buffer = "";                                                     // buffer for the console output, so we just print once...

            Console.WriteLine("Aufgabe 1: 0 .. 30");                                // self-explaining (ignore)
            {
                for (int i = 0; i <= 30; i += 3)
                {
                    counter++;
                    buffer += $"{i} ";
                }
                Console.WriteLine(buffer);
            }
            Console.WriteLine();

            counter = 0;
            buffer = "";

            Console.WriteLine("Aufgabe 2: 100 .. 0");                               // self-explaining (ignore)
            {
                for (int i = 100; i >= 0; i -= 5)
                {
                    counter++;
                    buffer += $"{i,3} ";
                    if (counter % 4 == 0) buffer += '\n';
                }
                Console.WriteLine(buffer);
            }
            Console.WriteLine();

            counter = 0;
            buffer = "";

            Console.WriteLine("Aufgabe 3: Dreistellige Zahlen");                    // we use a loop for each digit of the number
            {
                for (int h = 1; h < 10; h++)                                        // hundreds can start with one cause otherwise only two digits
                {
                    for (int t = 0; t < 10; t++)
                    {
                        for (int o = 0; o < 10; o++)
                        {
                            int number = (h * 100) + (t * 10) + o;
                            if (CanBeDevidedBy(number, h, t, o))                    // look below for info
                            {
                                counter++;
                                buffer += $"{number,3} ";
                                if (counter % 12 == 0) buffer += '\n';
                            }
                        }
                    }
                }
                Console.WriteLine(buffer);
            }
            Console.WriteLine();

            Console.WriteLine("Aufgabe 4: Summe der Zahlen 1..100");                // self-explaining (ignore)
            {
                int sum = 0;
                for (int i = 1; i <= 100; i++)
                {
                    sum += i;
                }
                Console.WriteLine($"Summe: {sum}");
            }
            Console.WriteLine();

            Console.WriteLine("Aufgabe 5: Letzter Wert vor Summe 1000");
            {
                int var = 1000;
                int idx = 0;
                while (var - idx++ > 0)                                             // we are starting from the back (var=1000); Each while check increments the idx
                {
                    var -= idx;
                }
                idx--;                                                              // decrement because last while check also incremented even if it was false
                Console.WriteLine($"Wert: {idx}");
            }
            Console.WriteLine();

            Console.WriteLine("Aufgabe 6: Reihenberechnung");
            {
                double x = 2;
                double sum = 0;
                // for loop with empty condition, terminated by break
                for (int i = 1; ; i += 4)                                           // start with 1 and for each iteration add 4
                {                                                                   // -> 1,3; 5,7; 9,11; 13,15; ...
                    double a = 1.0 / Power(x, i);                                   // we use our own power function and calculate the value
                    if (a < CancelNumber) break;
                    sum += a;

                    double b = 2.0 / Power(x, i + 2);
                    if (b < CancelNumber) break;
                    sum -= b;
                }
                Console.WriteLine($"Wert: {sum}");
            }

            Console.ReadLine();
        }

        /// <summary>
        /// Checks if the value can be divided by the factors if the factors contain zero 
        /// this will always return false. Otherwise, this will check for each factor if the 
        /// value can be divided by it without a left over.
        /// </summary>
        /// <param name="value">The number to check if it can be divided by the factors</param>
        /// <param name="factors">The factors to check</param>
        /// <returns><c>true</c> if can be divided or factors are not present, otherwise false</returns>
        private static bool CanBeDevidedBy(int value, params int[] factors)
        {
            foreach (int factor in factors)
            {
                if (factor == 0 || value % factor != 0) return false;
            }
            return true;
        }

        /// <summary>
        /// Calculates the base to the exponent power.
        /// Imortant: This is only for positive exponent!
        /// </summary>
        /// <param name="basis">The base number</param>
        /// <param name="exp">The exponent used to raise the base</param>
        /// <returns>A number representing the given base taken to the power of the given exponent</returns>
        private static double Power(double basis, double exp)
        {
            double result = 1;
            for (int i = 0; i < exp; i++)
            {
                result *= basis;
            }
            return result;
        }
    }
}
