﻿using System;

using static System.Math;

namespace Ohm.Homework
{
    class Funktionen
    {
        /* 
         * IMPORTANT: class System.Math is used with static so 
         * I can use members without class Math prefix. 
         * (ex. Max(...) or Min(...))
         */
        static void Main(string[] args)
        {
            Console.WriteLine("Wurzelberechnung mit dem Heronverfahren:");
            for (double d = 0; d <= 100; d += 10)
            {
                double heron = WurzelHeron(d);
                double math = Sqrt(d);
                Console.WriteLine($"{d,4} | {heron,8:F5} | {math,8:F5} | {math - heron,12}");
            }
            Console.WriteLine();

            Console.WriteLine("Berechnung der Zahl PI:");
            double pi = Pi(1000000);
            Console.WriteLine($"Pi: {pi} vs. {PI} = {pi - PI}");
            Console.WriteLine();

            Console.WriteLine("Flächenberechnung der Sin-Funktion");
            for (int i = 8; i <= 1024; i *= 2)
            {
                double flaeche = IterativeSinFlaechenberechnung(0, PI, i);
                Console.WriteLine($"{i,4} | {flaeche,10:F8} | {2.0 - flaeche,15:G6}");
            }

            Console.ReadLine();
        }

        /// <summary>
        /// Calculates the square root approximation.
        /// </summary>
        /// <param name="x">Number to get the root from</param>
        /// <returns>Approximation to sqrt</returns>
        static double WurzelHeron(double x)
        {
            double xn = x == 0 ? 1 : x;                 // xn is set to either x or 1 if if x is 0 [x0 != 0]
            do
            {
                xn = 0.5 * (xn + (x / xn));             // xn is reset to xn+1
            } while (Abs(x - xn * xn) > 1e-12);

            return xn;
        }

        /// <summary>
        /// Calculates the approximation if the number pi.
        /// </summary>
        /// <param name="points">Number of points</param>
        /// <returns>Approximation to pi</returns>
        static double Pi(int points)
        {
            Random random = new Random();
            double inner = 0;

            double x, y;
            for (int i = 0; i < points; i++)
            {
                x = random.NextDouble();
                y = random.NextDouble();

                double distance = (x * x) + (y * y);
                if (distance <= 1) inner++;             // if distance is smaller or equal to 1 it is in the circle
            }

            return (inner / points) * 4;                // calculate the ratio and multiply by 4 to get pi (cause ratio is pi/4)
        }

        /* 
         * INPORTANT (ignore for evaluation):
         *  These values are differant than the ones in the example, because they make one iteration to much or to little,
         *  which is the same because of the interval.
         *      - If one to little the surface is not added to the surfcae sum
         *      - If one ti much the surface is negative cause it is below the x-axis, and there for this is subtracted
         */

        /// <summary>
        /// Calculates the approximation area beneath the sinus curve in the interval.
        /// </summary>
        /// <param name="a">Endpoint of the interval</param>
        /// <param name="b">Endpoint of the interval</param>
        /// <param name="repeat">Number of iterations</param>
        /// <returns>Approximation to the area</returns>
        static double IterativeSinFlaechenberechnung(double a, double b, int repeat)
        {
            if (repeat < 1) return 0;                   // we need at least one iteration

            double offset = Min(a, b);                  // offset of the interval to origin
            double length = Max(a, b) - Min(a, b);      // length of the interval

            double stripe = length / (repeat * 2);      // width of one stripe with double the number of iterations, so
                                                        // the full width of one real stripe is 2 times the value

            double height = 0;                          // we just add the height to this value and calculate 
                                                        // the surface with the total height instead of each time
            for (int i = 0; i < repeat; i++)
            {
                height += Sin(offset + (i * 2 * stripe) + stripe);
            }

            return height * (stripe * 2);               // ^ one real stripe is needed for the surface
        }
    }
}
