﻿using System;
/*
 * Imported the Math class with the keyword static so we don't need to call
 * the class if we use some members of that class  
 */
using static System.Math;

namespace Ohm.Homework
{
    class Zylinder
    {
        static void Main(string[] args)
        {
            // just some information for the user
            {
                Console.ForegroundColor = ConsoleColor.Magenta;
                Console.WriteLine("Um die Anwendung zu beenden bitte Strg+C druecken!\n");
                Console.ResetColor();
            }

            Console.WriteLine("Berechnungen für einen Zylinder:");

            /*
             * If you don't know what methods are please look it up :-). I wrote the 
             * <c>NextDoubleValue</c> method which will read a double from the console
             * and return it to us. The method has the benefit that I can call it more than
             * once an reuse the code in the method.
             */
            do
            {
                Console.Write("Radius des Zylinders: ");
                double radius = NextDoubleValue(); // this is a method call ^

                Console.Write("Hoehe des Zylinders: ");
                double height = NextDoubleValue(); // this is a method call ^

                double circumference = 2 * PI * radius; // 2πr
                double volume = PI * Pow(radius, 2) * height; // πr²h
                double surface = circumference * (radius + height); // U(r+h)

                Console.WriteLine(
                    $"\n" +
                    $"Radius des Zylinders: {radius:F3}\n" +
                    $"Hoehe des Zylinders: {height:F3}\n" +
                    $"Umfang: {circumference:F3}\n" +
                    $"Volumen: {volume:F3}\n" +
                    $"Oberfläche: {surface:F3}\n"
                    );

                /*
                 * This loop will continue to run until the program is closed with 'ctrl + c'.  This 
                 * loop is called do-while and will at first execute the block and after that
                 * check the condition after the while. In this case, this is always true and
                 * therefore the programme will run again.
                 */
            } while (true);

        }

        static double NextDoubleValue()
        {
            double number;

            /*
             * This loop will repeat reading the input from the console until either a null
             * value is read or if the read input is a valid double. 
             * In the loop, the method <c>TryParse</c> will test the read string and if it is a
             * valid double the value is set to the local variable 'number'. If the read string
             * is not valid the TryParse will return the bool value false.
             * If the console input is false then some info is written to the console and the
             * loop should try again to read the next input (<c>continue</c>).
             * If for some reason the input should be null then an exception will be raised. 
             */
            string line;
            while ((line = Console.ReadLine()) != null)
            {
                if (!double.TryParse(line, out number))
                {
                    Console.ForegroundColor = ConsoleColor.DarkRed;
                    Console.WriteLine("Der eingegebene Wert ist keine gueltige Zahl!");
                    Console.ResetColor();
                    continue;
                }
                return number;
            }
            throw new InvalidOperationException();
        }
    }
}
