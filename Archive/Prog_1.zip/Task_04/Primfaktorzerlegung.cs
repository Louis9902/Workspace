﻿using System;

namespace Ohm.Homework
{
    class Primfaktorzerlegung
    {
        static void Main(string[] args)
        {
            int start = NextInt("Startwert eingeben: ");
            int close = NextInt("Endwert eingeben: ");

            for (int i = start; i <= close; i++)
            {
                Console.WriteLine(PrimeFactorization(i));
            }

            Console.ReadLine();
        }

        private static string PrimeFactorization(int value)
        {
            string result = $"{value}: ";                   // string builder for result

            int divisor = 2;                                // part of the algorithm
            bool flag = false;                              // flag to check if we have already a prim factor (default: false)
            while (value >= divisor)
            {
                if (value == divisor && !flag)              // if the numer is equal to the divisor and we have't found any prime factor (flag)
                {                                           // we know it is prime number
                    return result += "Primzahl";
                }

                if (value % divisor == 0)                   // part of the algorithm
                {
                    // str += value > divisor ? $"{divisor} * " : $"{divisor}";
                    // ^ does the same as below but is more compact...

                    result += divisor;
                    if (value > divisor)                    // only add the ' * ' if we have more to add after
                    {
                        result += " * ";
                    }

                    flag = true;                            // change flag because we have found a prime factor
                    value /= divisor;
                }
                else
                {
                    divisor++;                              // part of the algorithm
                }
            }

            return result;
        }

        // should be self explaining... just a safe int read function
        private static int NextInt(string prefix)
        {
            Console.Write(prefix);
            int result;
            while (!int.TryParse(Console.ReadLine(), out result))
            {
                Console.WriteLine("Bitte machen sie eine gueltige eingabe!");
                Console.Write(prefix);
            }
            return result;
        }
    }
}
