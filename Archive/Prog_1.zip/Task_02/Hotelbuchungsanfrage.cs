﻿using System;

namespace Ohm.Homework
{
    /**
     * Some important things to know:
     *  - all prices are handled as an int (in cents) and not as double because of 
     *    the double inaccuracy
     *  - all outputs to the console are within a special block which has no purpose 
     *    other than to keep the code clean and make it more readable
     *  - If you don't know what functions or methods are, please consider to look
     *    it up. I use those to avoid redundant code.
     **/
    class Hotelbuchungsanfrage
    {
        private const int PriceDefault = 8950;
        private const int PriceDecreaseOne = 7950;
        private const int PriceDecreaseTwo = 6000;

        private const int Discount = 10;

        private const double DivisorPrice = 100.0;

        static void Main(string[] args)
        {
            do
            {
                {
                    Console.WriteLine("Djangos Hotel");
                    Console.WriteLine("=============");
                }

                int amount = NextInt("Wieviel Tage wollen Sie bei uns bleiben? ");
                int humans = NextInt("Wie viele Personen sind Sie? ");

                {
                    Console.WriteLine();
                    Console.WriteLine($"Ihr Angebot für {humans} Personen für {amount} Tage: ");
                    Console.WriteLine();
                    Console.WriteLine($"{humans / 2} Doppelzimmer, {humans % 2} Einzelzimmer ");
                    Console.WriteLine();
                }

                int pricePart = amount > 10 ? PriceDecreaseTwo : amount > 4 ? PriceDecreaseOne : PriceDefault;  // short if statement to compute the price per day

                int priceUnit = pricePart * amount;                                                     // price for all days for one human
                int priceFull = priceUnit * humans;                                                     // price for all days and all humans

                {
                    Console.WriteLine($"Grundpreis p.P./Tag: {pricePart / DivisorPrice,15:C}");         // 21+15 = 36 (line size calc)
                    Console.WriteLine($"  x  {amount,5} Tage: {priceUnit / DivisorPrice,19:C}");        // 17+19 = 36 (line size calc)
                    Console.WriteLine($"  x  {humans,5} Personen: {priceFull / DivisorPrice,15:C}");    // 21+15 = 36 (line size calc) 
                }

                int bonus = humans * amount >= 20 ? priceFull / Discount : 0;

                if (bonus != 0)                                                                          // print to console only if bonus is present
                {
                    Console.WriteLine($"  ~  {Discount,4}% Rabatt: {bonus / DivisorPrice,17:C}");       // 19+17 = 36 (line size calc)
                }

                {
                    Console.WriteLine(new String('-', 36));                                             // create separator with line length
                    Console.WriteLine($"Endbetrag: {(priceFull - bonus) / DivisorPrice,25:C}");         // 11+25 = 36 (line size calc)
                    Console.WriteLine();
                }

            } while (CanProgramContinue());
        }

        private static int NextInt(string prefix)
        {
            int result = 0;
            Console.Write(prefix);

            while (!int.TryParse(Console.ReadLine(), out result))                                   // try to parse the user input, if valid no looping otherwise loop to repeat user input
            {
                Console.SetCursorPosition(0, Console.CursorTop - 1);                                // set the cursor of the console to the previous line start
                {
                    Console.ForegroundColor = ConsoleColor.Red;                                     // sets the console color ro red
                    Console.WriteLine("Bitte geben sie einen gueltigen Werte ein!");                // prints a line in red
                    Console.ResetColor();                                                           // reset the color to the default
                }
                Console.Write(prefix);
            }

            return result;
        }

        private static bool CanProgramContinue()
        {
            Console.WriteLine("Press any key to continue or 'Q' to quit the program.");
            bool result = char.ToUpperInvariant(Console.ReadKey().KeyChar) != 81;                   // waits for an user input
            Console.Clear();                                                                        // clear console after the input
            return result;
        }
    }
}
