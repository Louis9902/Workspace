﻿using System;
using System.Text;

namespace Ohm.Homework
{
    public class TicTacToe
    {
        internal static void Main(string[] args)
        {
            Console.OutputEncoding = Encoding.UTF8;

            Console.WriteLine(@"╔══════════════════════════════════════════════╗");
            Console.WriteLine(@"║  _____ _     _____          _____            ║");
            Console.WriteLine(@"║ /__   (_) __/__   \__ _  __/__   \___   ___  ║");
            Console.WriteLine(@"║   / /\/ |/ __|/ /\/ _` |/ __|/ /\/ _ \ / _ \ ║");
            Console.WriteLine(@"║  / /  | | (__/ / | (_| | (__/ / | (_) |  __/ ║");
            Console.WriteLine(@"║  \/   |_|\___\/   \__,_|\___\/   \___/ \___| ║");
            Console.WriteLine(@"╚══════════════════════════════════════════════╝");
            Console.WriteLine(@"                                                ");

            do
            {
                var matrix = CreateMatrix();
                var user = 1;
                var counter = 1;

                // check if the user has won or if the game is over and no one has won
                while (!DoUsersTurn(user, matrix) && counter < matrix.Length)
                {
                    user = user != 1 ? 1 : 2; // alternate the user id
                    counter++;
                }

                Console.Clear();
                Console.Write(MatrixToString(matrix));
                Console.WriteLine();

                if (counter < matrix.Length)
                {
                    Console.ForegroundColor = ConsoleColor.DarkYellow;
                    Console.WriteLine($"Der Spieler {user} hat das Spiel gewonnen! (Spielzüge: {counter})");
                }
                else
                {
                    Console.ForegroundColor = ConsoleColor.Magenta;
                    Console.WriteLine($"Kein Spieler hat das Spiel gewonnen!");
                }

                Console.ResetColor();

                Console.WriteLine();
                Console.WriteLine("Drücken sie 'n' für noch ein Spiel, oder eine andere Taste um zu beenden!");
            } while (Console.ReadKey().KeyChar == 'n');
        }

        /// <summary>
        /// Does one user turn with the check if the coords are valid or not.
        /// </summary>
        /// <param name="user">The user identifier</param>
        /// <param name="matrix">The matrix of the current game</param>
        /// <returns>true if the current user has won the game, false otherwise</returns>
        private static bool DoUsersTurn(int user, int[,] matrix)
        {
            Console.Clear();
            Console.WriteLine(MatrixToString(matrix));

            int row, col;
            while (!GetUserPos(user, matrix, out row, out col))
            {
                Console.Beep();
            }

            matrix[row, col] = user;

            return HasUserWon(user, matrix, row, col);
        }

        /// <summary>
        /// Promts the user to enter a row and column.
        /// </summary>
        /// <param name="user">The user identifier</param>
        /// <param name="matrix">The matrix of the current game</param>
        /// <param name="row">The choosen row index</param>
        /// <param name="col">The choosen coloumn index</param>
        /// <returns>true if the coords are valid otherwise false</returns>
        private static bool GetUserPos(int user, int[,] matrix, out int row, out int col)
        {
            Console.Write($"Spieler {user}: ");
            row = NextDigit(line: false) - 1;
            Console.Write(" • ");
            col = NextDigit(line: false) - 1;
            Console.WriteLine();

            if (row < matrix.GetLength(0) && col < matrix.GetLength(1))
            {
                return matrix[row, col] == 0;
            }

            return false;
        }

        /// <summary>
        /// Checks if the suer has won the game, this is check vertically, horizontally and also 
        /// diagonal.
        /// </summary>
        /// <param name="user">The user identifier</param>
        /// <param name="matrix">The matrix of the current game</param>
        /// <param name="row">The choosen row index</param>
        /// <param name="col">The choosen coloumn index</param>
        /// <param name="require">The required amount of elements orienteted in a certain way, default 3</param>
        /// <returns>true if the user has the required number of fields in row</returns>
        private static bool HasUserWon(int user, int[,] matrix, int row, int col, int require = 3)
        {
            // have of the possible offsets
            int[][] offsets = {new[] {-1, -1}, new[] {-1, 0}, new[] {-1, 1}, new[] {0, 1}};

            foreach (var offset in offsets)
            {
                var matches = 1;

                // vary between -1 and 1 to get the fully set of offsets
                for (var drift = -1; drift <= 1; drift += 2)
                {
                    var xDrift = offset[0] * drift;
                    var yDrift = offset[1] * drift;

                    // iterate the required amount to check for a continuous stroke
                    for (var move = 1; move < require; move++)
                    {
                        var x = row + xDrift * move; // the actual coords of the next field to check
                        var y = col + yDrift * move; // the actual coords of the next field to check

                        if (x < 0 || x >= matrix.GetLength(0)) break; // check for the out of bounds prevention
                        if (y < 0 || y >= matrix.GetLength(1)) break; // check for the out of bounds prevention

                        if (matrix[x, y] != user) break; // stop if the user does not own the field

                        matches++;
                    }
                }

                if (matches == require) return true;
            }

            return false;
        }

        /// <summary>
        /// Converts the matrix to a string formatted as grid with the values.
        /// Note: This is inefficent but we are not allowed to use a StringBuilder.
        /// </summary>
        /// <param name="matrix">The matrix to convert</param>
        /// <returns>The matrix as pretty string</returns>
        private static string MatrixToString(int[,] matrix)
        {
            var rows = matrix.GetLength(0);
            var cols = matrix.GetLength(1);

            var buffer = new string[3 + (rows * 2)];
            var l = buffer.Length - 1;

            buffer[0] = "    ╓";
            buffer[1] = "    ║";
            buffer[2] = "╒═══╬";
            buffer[4] = "├───╫";
            buffer[l] = "└───╨";

            for (var c = 0; c < cols; c++)
            {
                var flag = c < cols - 1;
                buffer[0] += $"───" + (flag ? '┬' : '┐');
                buffer[1] += $" {c + 1} │";
                buffer[2] += $"═══" + (flag ? '╪' : '╡');
                buffer[4] += $"───" + (flag ? '┼' : '┤');
                buffer[l] += $"───" + (flag ? '┴' : '┘');
            }

            for (var r = 0; r < rows; r++)
            {
                var index = 3 + r * 2;

                buffer[index] = $"│ {r + 1} ║";
                for (var c = 0; c < cols; c++)
                {
                    buffer[index] += $" {matrix[r, c]} │";
                }

                if (index + 1 != l)
                {
                    buffer[index + 1] = buffer[4];
                }
            }

            var result = "";
            foreach (var line in buffer)
            {
                result += line + '\n';
            }

            return result;
        }

        /// <summary>
        /// Create a new two dimensional array with the width and height choosen by the user.
        /// </summary>
        /// <returns>The newly create array</returns>
        private static int[,] CreateMatrix()
        {
            int row, col;
            do
            {
                Console.WriteLine("> Erstellen sie ein Spielfeld welches mindestens eine Größe von 3x3 hat: ");

                row = NextDigit("Zeilen  : ");
                col = NextDigit("Spalten : ");
            } while (row < 3 || col < 3);

            return new int[row, col];
        }

        /// <summary>
        /// Reads the next digit from the console, if it is not between '1' and '9' the written character
        /// is removed and the user can type again.
        /// </summary>
        /// <param name="prefix">Written before the input is read</param>
        /// <param name="line">If a new line should be written after succesful read</param>
        /// <returns>The numeric value of the input</returns>
        private static int NextDigit(string prefix = null, bool line = true)
        {
            Console.Write(prefix);
            int[] cursor = {Console.CursorLeft, Console.CursorTop};

            var digit = Console.ReadKey().KeyChar;
            while (digit < '1' || digit > '9')
            {
                Console.SetCursorPosition(cursor[0], cursor[1]); // reset cursor to override
                Console.Write(' ');
                Console.SetCursorPosition(cursor[0], cursor[1]);
                digit = Console.ReadKey().KeyChar;
            }

            if (line) Console.WriteLine();
            return digit - '0'; // to get the actual numeric value we sub '0' (48 in ascii)
        }
    }
}