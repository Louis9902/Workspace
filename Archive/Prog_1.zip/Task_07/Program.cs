﻿using System;
using System.Linq;
using System.Text;
using System.Threading;

namespace Task_07
{
    internal static class Program
    {
        /*
         * Zunächst einmal ist das meine Lösung für die Aufgabenstellung, jedoch muss ich anmerken das ich
         * mir etwas mehr Freiraum bei der Bearbeitung dieser Aufgabe genommen habe.
         *
         * ABER es wird immer noch all das gemacht was verlangt wird,
         * nur einige Bezeichnungen sind unterschiedlich (weil Englisch und so…)
         * Ich hoffe das das nicht unbedingt ein Problem ist…, mir ist aber auch bewusst das
         * man sich in der Klausur an die Aufgabenstellung halten muss
         * und Klassen auch in unterschiedliche datein schreiben sollte.
         */

        public static void Main(string[] args)
        {
            // Kommentieren Sie zunächst alles aus, was Sie noch nicht implementiert haben
            // und arbeiten Sie sich schrittweise vor

            var p1 = new Member("Kai Pirinha", 1993, "kaipi@friends.com");
            var p2 = new Member("Bilbo Buggins") {Email = "bb@freebee.com"};

            var p3 = new Member("Sam Gamgee", 2001);
            var p4 = new Member("Pina Kolada", 1999);
            var p5 = new Member("Galadriel", 1990);
            var p6 = new Member("Kati Kapinski");
            var p7 = new Member("Dana Scully", 1980, "danny@thn.edu");
            var p8 = new Member("James T. Kirk", 1993);

            var v1 = new Organization("Freunde von Pi", p1, p2, p3, p4, p5, p6, p7, p8);
            Console.WriteLine(v1);

            Console.WriteLine("\nMitglieder mit Pi:");
            v1.HasMemberWithPi();

            Console.WriteLine("\nAlter Hase: " + v1.SearchOldestMember());

            Console.WriteLine("\nSuche(Galadriel): " + v1.Search("Galadriel"));

            var members = new Member[4];
            members[0] = new Member("Kai Pirinha");
            members[1] = new Member("Dana Scully", 1990);
            members[2] = new Member("Jean-Luc Skywalker", 1950);
            members[3] = new Member("Luke Picard");

            var v2 = new Organization("Freunde von Pu", members);
            Console.WriteLine();
            Console.WriteLine(v2);

            Console.WriteLine("\nSchnittmenge:");
            Organization.Overlap(v1, v2);

            // Ungültige Jahresangaben

            Console.WriteLine();
            try
            {
                var member = new Member("Betty Rourke", 1905);
                Console.WriteLine("Diese Code-Zeile darf wg. ungültigem Jahr nicht erreicht werden!");
            }
            catch (Exception e)
            {
                Console.WriteLine("Exception korrekt generiert:\n" + e.Message);
            }

            Console.WriteLine();
            try
            {
                var member = new Member("Betty Rourke") {Year = 1905};
                Console.WriteLine("Diese Code-Zeile darf wg. ungültigem Jahr nicht erreicht werden!");
            }
            catch (Exception e)
            {
                Console.WriteLine("Exception korrekt generiert:\n" + e.Message);
            }
        }
    }

    internal class Organization
    {
        public Organization(string name, params Member[] members)
        {
            Name = name;
            Members = members;
        }

        private string Name { get; }
        private Member[] Members { get; }

        public static void Overlap(Organization left, Organization right)
        {
            //linq expression queries for the search operation 
            left.Members
                .Select(next => next.Name)
                .Where(next => right.Search(next) != null)
                .ToList().ForEach(Console.WriteLine);
        }

        public void HasMemberWithPi()
        {
            foreach (var member in Members)
            {
                for (var i = 0; i < Name.Length - 1; i++)
                {
                    if ((Name[i] == 'P' || Name[i] == 'p') && (Name[i + 1] == 'I' || Name[i + 1] == 'i'))
                    {
                        Console.WriteLine(member);
                        break;
                    }
                }
            }
        }

        public Member SearchOldestMember()
        {
            // sort increasing order by year (1990 -> 2000)
            return Members.OrderBy(next => next.Year).First();
        }

        public Member Search(string name)
        {
            // the default (default(T), where T is a class is null) -> first or null that match predicate
            return Members.FirstOrDefault(next => name.Equals(next.Name));
        }

        public override string ToString()
        {
            var builder = new StringBuilder();
            builder.AppendFormat("Organization: {0}", Name).AppendLine();
            foreach (var member in Members)
            {
                builder.Append(member).AppendLine();
            }

            return builder.ToString();
        }
    }

    internal class Member
    {
        private const int YearSince = 1950;
        private static readonly int YearNow = DateTime.Now.Year;
        
        private static int _identifier;

        private int _year;

        public Member(string name, int year = -1, string email = null)
        {
            Identifier = Interlocked.Increment(ref _identifier); // you never know, so thread safety first...
            Name = name;
            Email = email;
            Year = year != -1 ? year : YearNow;
        }

        private int Identifier { get; set; }

        public string Name { get; }
        public string Email { get; set; }

        public int Year
        {
            get => _year;
            set
            {
                if (value < YearSince || value > YearNow)
                {
                    // This is intentional not named as in the task description!
                    throw new ArgumentOutOfRangeException("Year");
                }

                _year = value;
            }
        }

        public override string ToString()
        {
            var builder = new StringBuilder();
            builder.AppendFormat("Member {0}: {1}", Identifier, Name);
            if (!string.IsNullOrEmpty(Email)) builder.AppendFormat(", {0}", Email);
            builder.AppendFormat(", joined: {0}", Year);
            return builder.ToString();
        }
    }
}