﻿using System;

namespace Ohm.Homework
{
    public class Kniffel
    {
        static void Main(string[] args)
        {
            var random = new Random();

            var counter = 0;
            var buffer = CreateBuffer();

            bool repeat;
            do
            {
                repeat = false; // reset the repeat flag
                counter++;

                for (var i = 0; i < buffer.Length; i++) // fill the array with the random numbers
                {
                    buffer[i] = random.Next(1, 7);
                }

                Console.Write($"{counter,6}. Wurf: {buffer[0]}");
                for (var i = 1; i < buffer.Length; i++)
                {
                    Console.Write($", {buffer[i]}");
                    if (!repeat && buffer[0] != buffer[i]) // if we have no continues stroke we must try again
                    {
                        repeat = true;
                    }
                }

                Console.WriteLine();
            } while (repeat);

            Console.WriteLine($"Kinffel nach dem {counter}. Wurf!\n");

            Console.WriteLine("Press any key to continue...");
            Console.ReadKey();
        }

        /// <summary>
        /// Creates a new buffer with the size determint by the user.
        /// This has a length with the minimal length of 2.
        /// </summary>
        /// <returns>The newly created array</returns>
        static int[] CreateBuffer()
        {
            int result;
            while ((result = NextDigit("Anzahl der Würfel: ")) < 2)
            {
                Console.WriteLine("Es sollten mindestens 2 Würfel benutzt werden!");
            }

            return new int[result];
        }

        /// <summary>
        /// Reads the next digit from the console, if it is not between '1' and '9' the written character
        /// is removed and the user can type again.
        /// </summary>
        /// <param name="prefix">Written before the input is read</param>
        /// <param name="line">If a new line should be written after succesful read</param>
        /// <returns>The numeric value of the input</returns>
        static int NextDigit(string prefix = null, bool line = true)
        {
            Console.Write(prefix);
            int[] cursor = {Console.CursorLeft, Console.CursorTop};

            var digit = Console.ReadKey().KeyChar;
            while (digit < '1' || digit > '9')
            {
                Console.SetCursorPosition(cursor[0], cursor[1]);
                Console.Write(' ');
                Console.SetCursorPosition(cursor[0], cursor[1]);
                digit = Console.ReadKey().KeyChar;
            }

            if (line) Console.WriteLine();
            return digit - '0';
        }
    }
}