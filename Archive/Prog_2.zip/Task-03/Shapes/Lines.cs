using System;

namespace TextGraphics
{
    // abstract class so lines are unified
    public abstract class Line : Shape
    {
        protected readonly int Length;

        protected Line(uint length, ConsoleColor color) : base(color)
        {
            Length = (int) length;
        }
        
    }

    public class HorizontalLine : Line
    {
        public HorizontalLine(uint width, ConsoleColor color) : base(width, color)
        {
        }

        public override void Paint(int left, int top, Image image)
        {
            for (var x = 0; x < Length; x++)
            {
                image.SetColor(left + x, top, Color);
            }
        }
    }

    public class VerticalLine : Line
    {
        public VerticalLine(uint height, ConsoleColor color) : base(height, color)
        {
        }

        public override void Paint(int left, int top, Image image)
        {
            for (var y = 0; y < Length; y++)
            {
                image.SetColor(left, top + y, Color);
            }
        }
    }
}