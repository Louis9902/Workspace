using System;

namespace TextGraphics
{
    public class Rectangle : Shape
    {
        protected readonly uint Width;
        protected readonly uint Height;

        public Rectangle(uint width, uint height, ConsoleColor color) : base(color)
        {
            Width = width;
            Height = height;
        }

        public override void Paint(int left, int top, Image image)
        {
            var y0 = top;
            var y1 = top + (Height - 1);
            for (var i = 0; i < Width; i++) // draw vertical lines <---> (top and bottom layer)
            {
                image.SetColor(left + i, y0, Color);
                image.SetColor(left + i, (int) y1, Color);    // why though? cast really why the heck aren't we allowed to change this fucking code...
            }

            var x0 = left;
            var x1 = left + (Width - 1);
            for (var i = 0; i < Height; i++) // draw horizontal lines ^v (left and right layer)
            {
                image.SetColor(x0, top + i, Color);
                image.SetColor((int) x1, top + i, Color); // why though? cast really why the heck aren't we allowed to change this fucking code...
            }
        }
    }

    public class FilledRectangle : Rectangle
    {
        public FilledRectangle(uint width, uint height, ConsoleColor color) : base(width, height, color)
        {
        }

        public override void Paint(int left, int top, Image image)
        {
            for (var x = 0; x < Width; x++)
            {
                for (var y = 0; y < Height; y++)
                {
                    image.SetColor(left + x, top + y, Color);
                }
            }
        }
    }
}