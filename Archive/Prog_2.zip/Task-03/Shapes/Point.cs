using System;

namespace TextGraphics
{
    public class Point : Shape
    {
        public Point(ConsoleColor color) : base(color)
        {
        }

        public override void Paint(int left, int top, Image image)
        {
            image.SetColor(left, top, Color);
        }
    }
}