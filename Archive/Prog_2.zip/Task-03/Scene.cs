﻿// Nuremberg Institute of Applied Technology - Faculty of Computer Science 
// Programming II - Practical Exercise "Inheritance" - Summer Semester 2019
// Prof. Dr. Bartosz von Rymon Lipinski (bartosz.vonrymonlipinski@th-nuernberg.de)

namespace TextGraphics
{
    // List data structure for scene elements:

    public class Scene
    {
        // Painting component, describing a shape object with 2d position information (left, top):

        public class Painting
        {
            public readonly Shape Shape;

            public readonly int Left;
            public readonly int Top;

            public Painting(int left, int top, Shape shape)
            {
                Left = left;
                Top = top;
                Shape = shape;
            }
        }


        // Scene (list) element, consists of paintings and 2d positional offset information: 

        public class Element
        {
            public readonly Painting[] Paintings;
            public int XOffset;
            public int YOffset;

            public Element Next;

            // default args set to zero to fulfill requirements
            public Element(Painting[] paintings, int xOffset = 0, int yOffset = 0)
            {
                Paintings = paintings;
                XOffset = xOffset;
                YOffset = yOffset;
            }
        }


        // Access to first and last scene elements:

        public Element First { get; set; }

        public Element Last
        {
            // compute property for last element in list
            get
            {
                if (First is null) return null;
                var cursor = First;
                do
                {
                    if (cursor.Next is null) return cursor;
                } while ((cursor = cursor.Next) != null);

                return null;
            }
        }


        // Scene construction operations:

        public Element Add(params Painting[] paintings)
        {
            var news = new Element(paintings);
            var last = Last;

            if (last == null)
            {
                First = news;
            }
            else
            {
                last.Next = news;
            }

            return news;
        }


        // Rendering of scene to a target image:

        public void Render(Image image)
        {
            // Traverse scene list elements and included paintings:

            for (Element element = First; element != null; element = element.Next)
            {
                foreach (var painting in element.Paintings)
                {
                    // Render each painting component using its 2d position and the offset of the corresponding scene element:

                    painting.Shape.Paint(painting.Left + element.XOffset, painting.Top + element.YOffset, image);
                }
            }
        }
    }
}