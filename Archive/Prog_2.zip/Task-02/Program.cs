﻿using System;
using System.Text;

namespace Ohm.Coursework.Task02
{
    public class Program
    {
        private static Test Test { get; } = new Test();

        // Most if this is just testing for false and true results.
        // The test class is just so it look pretty in the console.
        public static void Main(string[] args)
        {
            Console.OutputEncoding = Encoding.UTF8;

            TestTests();

            Console.WriteLine("Press key for actual tests...");
            Console.ReadKey();

            const string nameOfManagerA = "Manager #1";
            var birthOfManagerA = new DateTime(1988, 6, 12);
            var hireOfManagerA = new DateTime(2002, 8, 21);

            var managerA1 = new Employee(nameOfManagerA, birthOfManagerA, hireOfManagerA, new[] {"address abc alpha"},
                300000);
            var managerA2 = new Employee(nameOfManagerA, birthOfManagerA, hireOfManagerA, new[] {"address abc kappa"},
                300000);

            const string nameOfManagerB = "Manager #2";
            var birthOfManagerB = new DateTime(1998, 2, 19);
            var hireOfManagerB = new DateTime(2009, 3, 15);

            var managerB1 = new Employee(nameOfManagerB, birthOfManagerB, hireOfManagerB, new[] {"address abc gamma"},
                250000);

            managerA1.AddSkill("Cooking");
            managerA1.AddSkill("Programming");

            #region Employees

            Test.OpenSection("Employees");
            {
                Test.OpenSection("Testing equality operations");
                {
                    Test.AssertTrue(managerA1 == managerA2);
                    Test.AssertFalse(managerA1 != managerA2);

                    Test.AssertTrue(managerA1 != managerB1);
                    Test.AssertFalse(managerA1 == managerB1);
                }
                Test.ExitSection();

                Test.OpenSection("Testing skills results");
                {
                    Test.AssertTrue(managerA1.GetSkills() == "Cooking; Programming; ");
                    Test.AssertTrue(managerB1.GetSkills() == "");

                    Test.AssertFalse(managerA2.GetSkills() == "Cooking; Programming; ");
                    Test.AssertTrue(managerA2.GetSkills() == "");
                }
                Test.ExitSection();
            }
            Test.ExitSection();

            #endregion

            var membersA = new Employee[15];
            var membersB = new Employee[15];
            for (var i = 0; i < 15; i++)
            {
                membersA[i] = CreateSampleEmployee($"Employee A #{i}");
                membersB[i] = CreateSampleEmployee($"Employee B #{i}");
            }

            var membersA1 = new Employees();
            var membersA2 = new Employees();

            for (var index = 0; index < 15; index++)
            {
                membersA1 += membersA[index];
                membersA2 += membersA[index];
            }

            var membersB1 = new Employees();
            for (var index = 0; index < 10; index++)
            {
                membersB1 += membersB[index];
            }

            var membersB2 = ~membersB1;

            Test.OpenSection("Employees List");
            {
                Test.OpenSection("Testing equality operations");
                {
                    Test.AssertTrue(membersA1 == membersA2);
                    Test.AssertTrue(membersB1 == membersB2);

                    Test.AssertFalse(membersA1 != membersA2);
                    Test.AssertFalse(membersB1 != membersB2);

                    Test.AssertTrue(membersA1 != membersB1);
                    Test.AssertTrue(membersB2 != membersA2);
                }
                Test.ExitSection();

                Test.OpenSection("Size comparison of lists");
                {
                    Test.AssertTrue(membersA1 > membersB2);
                    Test.AssertTrue(membersA1 >= membersB2);

                    Test.AssertFalse(membersB1 > membersA2);
                    Test.AssertFalse(membersB1 >= membersA2);
                }
                Test.ExitSection();
            }
            Test.ExitSection();

            // projects tests are missing because of the often changing task description...
            // so i'm lazy...

            Test.ExitSection();
            Test.Results();
        }

        private static void TestTests()
        {
            var test = new Test();
            test.AssertTrue(true, "should be correct #1");
            test.AssertTrue(false, "should be false #1");
            test.AssertFalse(true, "should be false #2");
            test.AssertFalse(false, "should be correct #2");
            test.Results();
        }

        // create employee sample with random values
        private static Employee CreateSampleEmployee(string name)
        {
            var random = new Random();
            return new Employee(
                $"{name}",
                new DateTime(random.Next(1970, 2001), random.Next(1, 13), random.Next(1, 29)),
                new DateTime(random.Next(2000, 2015), random.Next(1, 13), random.Next(1, 29)),
                new[] {$"Placeholder {name}"},
                145000 + (uint) random.Next(0, 10000)
            );
        }
    }
}