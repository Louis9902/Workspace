using System;

namespace Ohm.Coursework.Task02
{
    public class Employees
    {
        private LinkNode crown;
        private int size;

        public Employees()
        {
        }

        private void Insert(Employee employee)
        {
            var wrapper = new LinkNode(employee);
            if (crown != null)
                InsertFront(wrapper, crown);
            else
                InsertEmpty(wrapper);
        }

        private void Remove(Employee employee)
        {
            var wrapper = Search(employee);
            if (wrapper != null)
                Remove(wrapper);
        }

        /// <summary>
        /// Inserts a new if no node is present, this links the crown and updates the references.
        /// </summary>
        /// <param name="insert">the node to insert in the chain</param>
        private void InsertEmpty(LinkNode insert)
        {
            insert.Prior = insert;
            insert.After = insert;
            crown = insert;
            size++;
        }

        /// <summary>
        /// Inserts a node in front of another node.
        /// Logic see the example:
        /// <code>
        ///     W1(P=W4|N=W2) W2(P=W1|N=W3) |HERE| W3(P=W2|N=W4) W4(P=W3|N=W1) + W8(P=??|N=??) [in front of W3]
        ///     => W1(P=W4|N=W2) W2(P=W1|N=W8) W8(P=W2|N=W3) W3(P=W8|N=W4) W4(P=W3|N=W1)
        /// </code>
        /// </summary>
        /// <param name="insert">the node to insert in the chain</param>
        /// <param name="node">the reference of the node where the new one should be inserted from</param>
        private void InsertFront(LinkNode insert, LinkNode node)
        {
            insert.Prior = node; // W8(P=??|N=W3)
            insert.After = node.After; // W8(P=W2|N=W3)
            node.After.Prior = insert; // W3(P=W2(P=W1|N=W8)|N=W4) => W2(P=W1|N=W8)
            node.After = insert; // W3(P=W8|N=W4)
            size++;
        }

        private void Remove(LinkNode remove)
        {
            if (remove.Prior != remove)
            {
                remove.Prior.After = remove.After;
                remove.After.Prior = remove.Prior;
                if (crown == remove)
                    crown = remove.Prior;
            }
            else
            {
                crown = null;
            }

            size--;
        }

        private LinkNode Search(Employee @object)
        {
            if (crown == null) return null;

            var cursor = crown;
            do
            {
                if (cursor.Object == @object)
                    return cursor;
            } while ((cursor = cursor.After) != crown);

            return null;
        }

        // testing for null and similar references before comparing content
        public override bool Equals(object obj)
        {
            if (ReferenceEquals(null, obj)) return false;
            if (ReferenceEquals(this, obj)) return true;
            return obj is Employees other && Equals(other);
        }

        // comparing the actual content of the list
        private bool Equals(Employees other)
        {
            if (size != other.size) return false;
            if (crown == null) return true;

            var cursor = other.crown;
            do
            {
                if (Search(cursor.Object) == null)
                    return false;
            } while ((cursor = cursor.After) != other.crown);

            return true;
        }

        #region Additive Operators

        public static Employees operator +(Employees list, Employee employee)
        {
            list.Insert(employee);
            return list;
        }

        public static Employees operator -(Employees list, Employee employee)
        {
            list.Remove(employee);
            return list;
        }

        public static Employees operator +(Employees list, Employees employees)
        {
            if (employees.crown == null) return list;

            var cursor = employees.crown;
            do
            {
                list.Insert(cursor.Object);
            } while ((cursor = cursor.After) != employees.crown);

            return list;
        }

        public static Employees operator -(Employees list, Employees employees)
        {
            if (employees.crown == null) return list;

            var cursor = employees.crown;
            do
            {
                list.Remove(cursor.Object);
            } while ((cursor = cursor.After) != employees.crown);

            return list;
        }

        #endregion

        #region Relational Operators

        public static bool operator >(Employees left, Employees right)
        {
            return left.size > right.size;
        }

        public static bool operator >=(Employees left, Employees right)
        {
            return left.size >= right.size;
        }

        public static bool operator <(Employees left, Employees right)
        {
            return left.size < right.size;
        }

        public static bool operator <=(Employees left, Employees right)
        {
            return left.size <= right.size;
        }

        #endregion

        #region Equality Operators

        public static bool operator ==(Employees left, Employees right)
        {
            return Equals(left, right);
        }

        public static bool operator !=(Employees left, Employees right)
        {
            return !Equals(left, right);
        }

        #endregion

        // just for convenience sake
        public static Employees operator ~(Employees list)
        {
            var clone = new Employees();
            clone += list;
            return clone;
        }

        /// <summary>
        /// Class for linking the Employees together without having the references in the Employee class.
        /// </summary>
        private sealed class LinkNode
        {
            public readonly Employee Object;
            public LinkNode Prior;
            public LinkNode After;

            public LinkNode(Employee @object)
            {
                if (@object == null) throw new ArgumentNullException(nameof(@object));
                Object = @object;
            }
        }
    }
}