using System;
using System.Text;

namespace Ohm.Coursework.Task02
{
    
    // PLEASE IGNORE THIS IS JUST FOR TESTING AND HAS NOTHING TO DO WITH THE TASK
    // THIS CONTAINS JUST LOGIC FOR TESTING AND PRINTING THE RESULTS IN A PRETTY WAY
    
    public class Test
    {
        private uint Tests { get; set; }
        private uint Sections { get; set; }

        private uint Passed { get; set; }
        private uint Failed { get; set; }
        private uint Actions => Passed + Failed;

        public void OpenSection(string name)
        {
            Sections++;
            Console.WriteLine(Header(name));
        }

        public void ExitSection()
        {
            Console.WriteLine(Footer());
            Sections--;
            Tests = 0;
        }

        private string Header(string name)
        {
            return "│  ".Repeat(Sections - 1) + $"├──┬─────────────── {name} ───────────────";
        }

        private string Footer()
        {
            return "│  ".Repeat(Sections);
        }

        private string Prefix()
        {
            return "│  ".Repeat(Sections) + "├╌╌";
        }

        public void AssertTrue(bool condition, string name = null)
        {
            if (condition)
                PrintSuccess(name);
            else
                PrintFailure(name);
        }

        public void AssertFalse(bool condition, string name = null)
        {
            if (!condition)
                PrintSuccess(name);
            else
                PrintFailure(name);
        }

        private void PrintFailure(string name)
        {
            var color = Console.ForegroundColor;
            Console.Write(Prefix());
            name = name ?? $"Test #{Tests++}";
            Console.ForegroundColor = ConsoleColor.DarkRed;
            Console.WriteLine($" ✖ {name} has failed");
            Console.ForegroundColor = color;
            Failed++;
        }

        private void PrintSuccess(string name)
        {
            var color = Console.ForegroundColor;
            Console.Write(Prefix());
            name = name ?? $"Test #{Tests++}";
            Console.ForegroundColor = ConsoleColor.DarkGreen;
            Console.WriteLine($" ✔ {name} has passed");
            Console.ForegroundColor = color;
            Passed++;
        }

        public void Results()
        {
            Console.WriteLine();
            var color = Console.ForegroundColor;
            Console.Write($">>> Total Tests: {Actions} | ");
            Console.ForegroundColor = ConsoleColor.DarkRed;
            Console.Write($"{Failed} Tests failed ✖ ");
            Console.ForegroundColor = color;
            Console.Write(" | ");
            Console.ForegroundColor = ConsoleColor.DarkGreen;
            Console.Write($"{Passed} Tests passed ✔ ");
            Console.ForegroundColor = color;
            Console.WriteLine();
        }
    }

    internal static class StringAddons
    {
        public static string Repeat(this string str, uint count)
        {
            if (count == 0) return string.Empty;
            if (count == 1) return str;
            var builder = new StringBuilder();
            for (var i = 0; i < count; i++) builder.Append(str);
            return builder.ToString();
        }
    }
}