using System;

namespace Ohm.Coursework.Task02
{
    public class Employee
    {
        // readonly means that it can only be set during the init of the object
        private readonly string name;
        private readonly DateTime dateOfBirth;
        private readonly DateTime dateOfHire;

        private string skills = "";

        public Employee(string name, DateTime dateOfBirth, DateTime dateOfHire, string[] address, uint salary)
        {
            this.name = name;
            this.dateOfBirth = dateOfBirth;
            this.dateOfHire = dateOfHire;
            Address = address;
            Salary = salary;
        }

        public string Name => name;
        public DateTime DateOfBirth => dateOfBirth;
        public DateTime DateOfHire => dateOfHire;

        public string[] Address { get; set; }
        public uint Salary { get; set; }

        public void AddSkill(string skill)
        {
            // since skills are only added and never removed we take it easy
            skills += $"{skill}; ";
        }

        public string GetSkills()
        {
            return skills;
        }

        // testing for null and similar references before comparing content
        public override bool Equals(object obj)
        {
            if (ReferenceEquals(null, obj)) return false;
            if (ReferenceEquals(this, obj)) return true;
            return obj is Employee other && Equals(other);
        }

        // comparing the actual content of the employees
        private bool Equals(Employee other)
        {
            return name.Equals(other.name) &&
                   dateOfBirth.Equals(other.dateOfBirth) &&
                   dateOfHire.Equals(other.dateOfHire);
        }

        #region Equality Operators

        public static bool operator ==(Employee left, Employee right)
        {
            return Equals(left, right);
        }

        public static bool operator !=(Employee left, Employee right)
        {
            return !Equals(left, right);
        }

        #endregion
    }
}