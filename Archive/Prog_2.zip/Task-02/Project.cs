namespace Ohm.Coursework.Task02
{
    
    public class Project
    {
        // readonly means that it can only be set during the init of the object
        private readonly string title;
        private Employee manager;
        private Employees employees;

        public string Title => title;
        public Employee Manager => manager;
        public Employees Employees => ~employees;

        public Project(string title, Employee manager, Employees employees)
        {
            this.title = title;
            this.manager = manager;
            this.employees = employees;
        }
        
        // testing for null and similar references before comparing content
        public override bool Equals(object obj)
        {
            if (ReferenceEquals(null, obj)) return false;
            if (ReferenceEquals(this, obj)) return true;
            return obj is Project other && Equals(other);
        }

        // comparing the actual content of the projects
        private bool Equals(Project other)
        {
            return title.Equals(other.title) &&
                   manager.Equals(other.manager) &&
                   employees.Equals(other.employees);
        }
        
        #region Additive Operators

        public static Project operator +(Project project, Employee employee)
        {
            project.manager = employee;
            return project;
        }

        public static Project operator +(Project project, Employees list)
        {
            project.employees += list;
            return project;
        }

        public static Project operator -(Project project, Employees list)
        {
            project.employees -= list;
            return project;
        }
        
        #endregion

        #region Relational Operators
        
        public static bool operator >(Project left, Project right)
        {
            return left.employees > right.employees;
        }

        public static bool operator >=(Project left, Project right)
        {
            return left.employees >= right.employees;
        }

        public static bool operator <(Project left, Project right)
        {
            return left.employees < right.employees;
        }

        public static bool operator <=(Project left, Project right)
        {
            return left.employees <= right.employees;
        }
        
        #endregion
        
        #region Equality Operators
        
        public static bool operator ==(Project left, Project right)
        {
            return Equals(left, right);
        }

        public static bool operator !=(Project left, Project right)
        {
            return !Equals(left, right);
        }
        
        #endregion

    }
}