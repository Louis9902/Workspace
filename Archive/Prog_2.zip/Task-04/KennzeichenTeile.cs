using System;
using System.Collections;

namespace Task_04
{
    public abstract class KennzeichenTeile<T> : IComparer
    {
        private static readonly Type Kennzeichen = typeof(Kennzeichen); // store the of Kennzeichen as static variable

        public abstract T Data { get; set; }

        public override string ToString()
        {
            return Data.ToString();
        }

        // check is string is in length bounds and has only letters
        protected static bool CheckMaxLetters(string letters, int max)
        {
            bool IsLetter(char c)
            {
                return c >= 'A' && c <= 'Z' || c >= 'a' && c <= 'z';
            }

            for (var i = 0; i < letters.Length; i++)
            {
                if (!IsLetter(letters[i])) return false;
                if (i >= max) return false;
            }

            return true;
        }

        public int Compare(object x, object y)
        {
            // if objects are not of type Kennzeichen escape with -1
            if (!Kennzeichen.IsInstanceOfType(x) || !Kennzeichen.IsInstanceOfType(y))
                return -1;

            var a = x as Kennzeichen;
            var b = y as Kennzeichen;

            return Compare(a, b); // compare Kennzeichen with the correct implementation
        }

        protected abstract int Compare(Kennzeichen a, Kennzeichen b);
    }

    public class KennzeichenOrt : KennzeichenTeile<string>
    {
        public sealed override string Data { get; set; }

        public KennzeichenOrt(string data)
        {
            if (!CheckMaxLetters(data, 3)) throw new InvalidKennzeichenStringException(3, data);
            Data = data;
        }


        protected override int Compare(Kennzeichen a, Kennzeichen b)
        {
            return a.Ort.Data.CompareTo(b.Ort.Data);
        }
    }

    public class KennzeichenBuchstabe : KennzeichenTeile<string>
    {
        public sealed override string Data { get; set; }

        public KennzeichenBuchstabe(string data)
        {
            if (!CheckMaxLetters(data, 2)) throw new InvalidKennzeichenStringException(2, data);
            Data = data;
        }

        protected override int Compare(Kennzeichen a, Kennzeichen b)
        {
            return a.Buchstabe.Data.CompareTo(b.Buchstabe.Data);
        }
    }

    public class KennzeichenZahl : KennzeichenTeile<int>
    {
        public sealed override int Data { get; set; }

        public KennzeichenZahl(int data)
        {
            if (data < 1 || data > 9999) throw new InvalidKennzeichenIntegerException(1, 9999, data);
            Data = data;
        }

        protected override int Compare(Kennzeichen a, Kennzeichen b)
        {
            return a.Zahl.Data.CompareTo(b.Zahl.Data);
        }
    }
}