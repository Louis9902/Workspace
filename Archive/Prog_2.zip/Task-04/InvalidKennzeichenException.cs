using System;

namespace Task_04
{
    public abstract class InvalidKennzeichenException : Exception
    {
        private string kennzeichenNachricht = "Kennzeichen ungültig: ";

        public virtual string KennzeichenNachricht { get; }

        protected InvalidKennzeichenException()
        {
            KennzeichenNachricht = kennzeichenNachricht; // add default message to property
        }
    }

    public class InvalidKennzeichenStringException : InvalidKennzeichenException
    {
        private const string MessageTemplate = "Bestandteil Ort darf nur {0:d} Buchstaben enthalten. War aber: {1}";

        private readonly int amount;
        private readonly string content;

        public override string KennzeichenNachricht =>
            base.KennzeichenNachricht + string.Format(MessageTemplate, amount, content); // extend the message with the template and insert args

        public InvalidKennzeichenStringException(int amount, string content)
        {
            this.content = content;
            this.amount = amount;
        }
    }

    public class InvalidKennzeichenIntegerException : InvalidKennzeichenException
    {
        private const string MessageTemplate =
            "Bestandteil Zahl darf nur eine Zahl zwischen [{0:d}, {1:d}] enthalten. War aber: {2:d}";

        private readonly int min, max;
        private readonly int content;

        public override string KennzeichenNachricht =>
            base.KennzeichenNachricht + string.Format(MessageTemplate, min, max, content); // extend the message with the template and insert args

        public InvalidKennzeichenIntegerException(int min, int max, int content)
        {
            this.min = min;
            this.max = max;
            this.content = content;
        }
    }
    
}